#include <iostream>

using namespace std;

void SwapXO(char& c);
void PrintError();
void PrintPattern(int iPatternHeight);

// Swap character between X and O
void SwapXO(char& c) { 
	c = (c == 'X' ? 'O' : 'X');
}

// Print an error message for an invalid input
void PrintError(){
	cout << "Invalid input; parameter must be a positive odd number\n\n";
}

// Print an XO pattern
void PrintPattern(int iPatternHeight)
{
	if (iPatternHeight>0 && iPatternHeight%2==1) {
		int half = iPatternHeight / 2; // needed to determine which character to begin the pattern with
		char c = (half % 2 == 0 ? 'X' : 'O'); // consecutive characters in the middle of each line
		char d = c;
		int pivot = 0; // determines when to begin the consecutive repetition of characters on each line
		
		int x,y = 0;
		for (y=0; y<iPatternHeight; y++) {
			for (x = 0; x < pivot; x++) { // alternating characters in the first half of each line
				cout << d;
				SwapXO(d);
			}
			for (x = 0; x < iPatternHeight - 2 * pivot; x++) { // consecutive characters in the middle of each line
				cout << c;
			}
			for (x = 0; x < pivot; x++) { // alternating characters in the second half of each line
				SwapXO(d);
				cout << d;
			}
			d = (half % 2 == 0 ? 'X' : 'O'); // reset d
			SwapXO(c); // swap c
			if (y < half) pivot++; // move the pivot towards the center
			else pivot--; // move the pivot away from the center
			cout << "\n";
		}
		cout << "\n";
	}
	else {
		PrintError();
	}
}

int main( int argc, const char* argv[] )
{
	int i;
	
	while(true) {
		cout << "iPatternHeight = ";
		if (cin >> i) {
			PrintPattern(i);
		}
		else {
			PrintError();
		}
		cin.clear();
		cin.ignore(numeric_limits<streamsize>::max(), '\n');
	}

}