
#include "Widget.h";
#include <algorithm> 

void Widget::RemoveAndDeleteAllWidgets() {
	for (unsigned int i=0;i<children.size();i++) {
		delete children[i]; 
		children[i] = NULL;
	}
	children.clear();
}

void PrintDebugInfo(Widget* _w, int indent) {
	for (int j=0;j<indent;j++) {
		cout << "\t" ;
	}
	string name = _w->name;
	cout << name << ": ";
	if (name.compare("ButtonWidget") == 0) {
		cout << "text = \"" << ((ButtonWidget*)_w)->t << "\",";
	}
	else if(name.compare("LabelWidget") == 0) {
		cout << "text = \"" << ((LabelWidget*)_w)->t << "\",";
	}
	else if(name.compare("PictureWidget") == 0) {
		cout << "img = " << ((PictureWidget*)_w)->f << ",";
	}
	else if(name.compare("DialogWidget") == 0) {
		cout << "header  = \"" << ((LabelWidget*)_w)->t << "\",";
	}
	cout << "x=" << _w->x << ",y=" << _w->y << ",w=" << _w->w << ",h=" << _w->h;
	for (int i=0;i<_w->children.size();i++) {
		PrintDebugInfo(_w->children[i], indent+1);
	}
	if (name.compare("ButtonWidget") == 0) {
		cout << ",enabled = " << (((ButtonWidget*)_w)->enabled ? "true" : "false");
	}
	cout << "\n";
}

void Widget::DebugInfo() {
	PrintDebugInfo(this,0);
}

void Widget::AddWidget(Widget* _w) {
	children.push_back(_w);
}

void Widget::RemoveWidget(Widget* _w) {
	children.erase(remove(children.begin(), children.end(), _w), children.end());
}

PanelWidget::PanelWidget(int _x, int _y, int _w, int _h) {
	name = "PanelWidget";
	x = _x;
	y = _y;
	w = _w;
	h = _h;
}

DialogWidget::DialogWidget(string _t, int _x, int _y, int _w, int _h) {
	name = "DialogWidget";
	t = _t;
	x = _x;
	y = _y;
	w = _w;
	h = _h;
}

LabelWidget::LabelWidget(string _t, int _x, int _y, int _w, int _h) {
	name = "LabelWidget";
	t = _t;
	x = _x;
	y = _y;
	w = _w;
	h = _h;
}

ButtonWidget::ButtonWidget(string _t, int _x, int _y, int _w, int _h) {
	name = "ButtonWidget";
	t = _t;
	x = _x;
	y = _y;
	w = _w;
	h = _h;
}

void ButtonWidget::SetEnabled(bool b) {
	enabled = b;
}

PictureWidget::PictureWidget(string _f, int _x, int _y, int _w, int _h) {
	name = "PictureWidget";
	f = _f;
	x = _x;
	y = _y;
	w = _w;
	h = _h;
}


