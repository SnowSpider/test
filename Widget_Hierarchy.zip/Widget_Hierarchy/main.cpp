/*
Widget Hierarchy Object Oriented Design Problem

Background
Many UI libraries utilize a widget-based hierarchy, where a widget is a graphical component that often provides generic, reusable functionality.  Widgets may contain other widgets. For example, a DialogWidget might function as a pop-up window that displays a message to the user and asks for confirmation.  The implementation of this widget might involve the usage of the following to construct its component functionality: a LabelWidget to display some text and two ButtonWidgets for the ��OK�� and ��Cancel�� buttons. The ButtonWidgets themselves may contain a LabelWidget or PictureWidget.

Problem
Design the basic class structures for a Widget based User Interface.  You don��t need to build the full working graphical mechanisms of the user interface.  Simply come up with the class structure for a handful of widgets such as ones mentioned above, give them some distinguishing properties, and provide a mechanism for printing out debug information.

Additional requirements:
-	Do not make any changes to the sample main() function 
-	Create appropriate base and child class functionality
-	Add appropriate widget construction, widget destruction, and child addition and child removal functionality.  The minimal base class functions required in the submission are in the sample code below.
-	Output the debug information in a manner that clearly displays the hierarchical structure.
*/

#include "Widget.h";

int main(int argc, char* argv[])
{
	// create the main screen
	Widget* mainScreen = new PanelWidget(0,0,800,600);

	// add background and icon images to the main screen
	Widget* background = new PictureWidget("background.jpg", 0, 0, 800, 600);
	Widget* icon = new PictureWidget("icon.jpg", 10, 10, 50, 50 );
	mainScreen->AddWidget(background);
	mainScreen->AddWidget(icon);

	// create a dialog and it to the main screen
	Widget* dialog = new DialogWidget("Quit", 100, 50, 200, 200);
	ButtonWidget* okButton = new ButtonWidget("OK", 150, 50, 50, 20);
	ButtonWidget* cancelButton = new ButtonWidget("Cancel", 150, 150, 50, 20);
	dialog->AddWidget(cancelButton);
	dialog->AddWidget(okButton);
	dialog->RemoveWidget(okButton);
	dialog->AddWidget(okButton);
	mainScreen->AddWidget(dialog);

	// Configure some widgets 
	okButton->SetEnabled( true );
	cancelButton->SetEnabled( true );

	// print the debug information
	mainScreen->DebugInfo();

	// Clean up
	mainScreen->RemoveAndDeleteAllWidgets();
	delete mainScreen;

	cin.get(); // TODO: remove this line if you want
}


/*
And simple output for the above code might look something like this, where the indentation clearly details the widget hierarchy:

C:\progtest\>progtest.ext
PanelWidget: x=0,y=0,w=800,h=600
  PictureWidget: img = background.jpg,x=0,y=0,w=800,h=600
  PictureWidget: img = icon.jpg,x=10,y=10,w=50,h=50
  DialogWidget: header = "Quit",x=100,y=50,w=200,h=200 
    ButtonWidget: text = "OK",x=10,y=150,w=50,h=20,enabled = true
    ButtonWidget: text = "Cancel",x=150,y=150,w=50,h=20,enabled = true
*/