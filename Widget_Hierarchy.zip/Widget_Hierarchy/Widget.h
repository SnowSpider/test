#ifndef __WIDGET_H__
#define __WIDGET_H__

#include <string> 
#include <iostream>
#include <vector>

using namespace std;

// abstract base class
class Widget 
{
	public:
		string name; // class name
		int x; // x position
		int y; // y position
		int w; // width
		int h; // height
		vector<Widget*> children;
		void RemoveAndDeleteAllWidgets();
		void DebugInfo();
		void AddWidget(Widget* _w);
		void RemoveWidget(Widget* _w);
};

// PanelWidget
class PanelWidget: public Widget {
	public:
		PanelWidget(int _x, int _y, int _w, int _h);
};

// DialogWidget
class DialogWidget: public Widget {
	public: 
		string t;
		DialogWidget(string _t, int _x, int _y, int _w, int _h);
};

// LabelWidget
class LabelWidget: public Widget {
	public: 
		string t;
		LabelWidget(string t, int _x, int _y, int _w, int _h);
};

// ButtonWidget
class ButtonWidget: public Widget {
	public: 
		string t;
		bool enabled;
		ButtonWidget(string t, int _x, int _y, int _w, int _h);
		void SetEnabled(bool b);
};

// PictureWidget
class PictureWidget: public Widget {
	public: 
		string f;
		PictureWidget(string f, int _x, int _y, int _w, int _h);
};

#endif